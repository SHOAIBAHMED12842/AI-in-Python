print ('Abdul Moiz')
print ('18b-011-cs-A')
print ('Assignment 0')

#Question 1

